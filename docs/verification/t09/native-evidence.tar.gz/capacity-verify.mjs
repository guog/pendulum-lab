import {createBrowser} from '/Users/guog/.codex/worktrees/110c/pendulum-lab/scripts/browser-driver.mjs'
import {writeFileSync,readFileSync,cpSync,openSync,writeSync,closeSync,fsyncSync,unlinkSync,statfsSync,readdirSync} from 'node:fs'
import assert from 'node:assert/strict'
const root='/tmp/pendulum-14-volume',art='/tmp/pendulum-14-evidence/native/'
const b=createBrowser('pendulum14',[],art+'browser-steps.jsonl')
const statsBefore=statfsSync(root)
b('click','#workspace-start')
b('wait','--fn','/已确认 (?:[1-9]|0\.[5-9])/.test(document.querySelector("#workspace-progress").textContent)')
const id=readdirSync(root+'/workspace/experiments')[0]
cpSync(root+'/workspace',art+'capacity-before',{recursive:true})
let filler=root+'/capacity-filler.bin', fd=openSync(filler,'w'), filled=0, failure
try {
 for(const size of [1024*1024,4096]) {
  try { for(let n=0;n<12800;n++){writeSync(fd,Buffer.alloc(size,0x5a));filled+=size} }
  catch(error){failure={name:error.name,code:error.code,message:error.message};if(error.code!=='ENOSPC')throw error}
 }
 try{fsyncSync(fd)}catch(error){failure={name:error.name,code:error.code,message:error.message}}
}finally{closeSync(fd)}
const statsFull=statfsSync(root)
writeFileSync(art+'capacity-action.json',JSON.stringify({id,statsBefore,statsFull,filled,failure},null,2))
try {
 b('wait','--fn','document.querySelector("#workspace-error").textContent.length>0')
 const error=b('get','text','#workspace-error'), progress=b('get','text','#workspace-progress')
 assert.match(progress,/状态 paused/)
 assert.equal(b('is','enabled','#workspace-resume'),'false')
 assert.equal(b('is','enabled','#workspace-stop'),'false')
 assert.equal(b('get','value','#workspace-history'),id,'current fault experiment auto-selected')
 b('click','#workspace-load')
 b('wait','--fn',`document.querySelector('#workspace-diagnostics').textContent.includes('${id}')`)
 const diagnostics=JSON.parse(b('get','text','#workspace-diagnostics'))
 writeFileSync(art+'capacity-diagnostics.json',JSON.stringify({error,progress,diagnostics},null,2))
 assert.equal(diagnostics.live_fault.storage_fault.name,'QuotaExceededError')
 assert.ok(diagnostics.confirmed_sim_time_s>=.5)
 b('screenshot',art+'capacity-frozen.png')
 b('click','#workspace-export')
 await new Promise(r=>setTimeout(r,500))
 const exported=JSON.parse(readFileSync('/Users/guog/Downloads/recovery-'+id+'.json','utf8'))
 assert.equal(exported.live_fault.storage_fault.name,'QuotaExceededError')
 writeFileSync(art+'capacity-export.json',JSON.stringify(exported,null,2))
 cpSync(root+'/workspace',art+'capacity-after-fault',{recursive:true})
}finally{unlinkSync(filler)}
b('click','#workspace-retry')
b('wait','--fn','!document.querySelector("#workspace-stop").disabled')
b('click','#workspace-stop')
b('wait','--fn','document.querySelector("#workspace-record").textContent.includes("sealed-verified")')
cpSync(root+'/workspace',art+'capacity-after-retry',{recursive:true})
process.stdout.write('capacity fault, current-history selection, export and retry passed\n')
