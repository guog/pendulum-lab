import {createBrowser} from '/Users/guog/.codex/worktrees/110c/pendulum-lab/scripts/browser-driver.mjs'
import {writeFileSync,readFileSync,cpSync} from 'node:fs'
import assert from 'node:assert/strict'
const art='/tmp/pendulum-14-evidence/native/'
const b=createBrowser('pendulum14',[],art+'browser-steps.jsonl')
const {diagnostics,error,progress}=JSON.parse(readFileSync(art+'capacity-diagnostics.json','utf8'))
assert.equal(diagnostics.live_fault.storage_fault.name,'InvalidStateError')
assert.match(error,/InvalidStateError/)
assert.equal(b('get','text','#workspace-progress'),progress)
assert.equal(b('get','value','#workspace-history'),diagnostics.experiment_id)
b('screenshot',art+'capacity-frozen.png')
b('click','#workspace-export')
await new Promise(r=>setTimeout(r,500))
const exported=JSON.parse(readFileSync('/Users/guog/Downloads/recovery-'+diagnostics.experiment_id+'.json','utf8'))
assert.equal(exported.live_fault.storage_fault.name,'InvalidStateError')
writeFileSync(art+'capacity-export.json',JSON.stringify(exported,null,2))
cpSync('/tmp/pendulum-14-volume/workspace',art+'capacity-after-fault',{recursive:true})
b('click','#workspace-retry')
b('wait','--fn','!document.querySelector("#workspace-stop").disabled')
b('click','#workspace-stop')
b('wait','--fn','document.querySelector("#workspace-record").textContent.includes("sealed-verified")')
cpSync('/tmp/pendulum-14-volume/workspace',art+'capacity-after-retry',{recursive:true})
process.stdout.write('actual ENOSPC on isolated image; Chrome InvalidStateError retained, frozen prefix/export/retry passed\n')
