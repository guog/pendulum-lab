import {createBrowser} from '/Users/guog/.codex/worktrees/110c/pendulum-lab/scripts/browser-driver.mjs'
import {readFileSync,readdirSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import assert from 'node:assert/strict'
const art='/tmp/pendulum-14-evidence/native/', phase='final-temp-before-close'
const earlier=new Set(readdirSync(art+'final-workspace/experiments'))
const id=readdirSync(art+phase+'/after-kill/experiments').find(id=>!earlier.has(id))
assert.ok(id)
const b=createBrowser('pendulum14',[],art+'final-reopen-steps.jsonl')
b('select','#workspace-history',id)
b('click','#workspace-load')
b('wait','--fn',`document.querySelector('#workspace-diagnostics').textContent.includes('${id}')`)
const diagnostics=JSON.parse(b('get','text','#workspace-diagnostics'))
assert.equal(diagnostics.status,'interrupted')
assert.equal(diagnostics.confirmed_sim_time_s,.5)
assert.ok(diagnostics.workspace_orphan_files.includes('tmp/pending.json.crswap'))
assert.equal(diagnostics.unconfirmed_tail.end_sim_time_s,null)
assert.equal(b('is','enabled','#workspace-resume'),'false')
b('click','#workspace-export')
await new Promise(r=>setTimeout(r,500))
const exported=JSON.parse(readFileSync('/Users/guog/Downloads/recovery-'+id+'.json','utf8'))
assert.equal(exported.recovery.record.output.samples.length,51)
const manifest=exported.recovery.record.manifest
for(const entry of [manifest.config,manifest.snapshot,manifest.result,...manifest.batches.flatMap(batch=>batch.files)]){
 const rel='/experiments/'+id+'/'+entry.path
 const before=readFileSync(art+phase+'/before-kill'+rel),after=readFileSync(art+phase+'/after-kill'+rel)
 assert.deepEqual(before,after)
 assert.equal(createHash('sha256').update(after).digest('hex'),entry.sha256)
 assert.equal(after.length,entry.byte_length)
}
writeFileSync(art+'final-reopened-export.json',JSON.stringify(exported,null,2))
writeFileSync(art+'final-reopen-result.json',JSON.stringify({status:'passed',phase,id,diagnostics,build:JSON.parse(readFileSync('/Users/guog/.codex/worktrees/110c/pendulum-lab/dist/build-info.json','utf8'))},null,2))
b('screenshot',art+'final-reopened.png')
console.log('final source actual Chrome crash, native reopen, temp-orphan diagnosis and export readback passed')
