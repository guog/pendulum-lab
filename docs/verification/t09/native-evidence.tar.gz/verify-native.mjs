import {openWorkspace} from '/Users/guog/.codex/worktrees/110c/pendulum-lab/src/workspace.ts'
import {readFile,readdir} from 'node:fs/promises'
import {readFileSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import assert from 'node:assert/strict'
const art='/tmp/pendulum-14-evidence/native'
async function workspace(root){return openWorkspace({permission:async(mode)=>mode==='read',list:path=>readdir(root+'/'+path),read:path=>readFile(root+'/'+path,'utf8'),write:async()=>{throw Error('readonly verifier')}})}
const results=[]
for(const phase of ['temp-before-close','manifest-before-close','committed-before-readback']){
 const root=art+'/'+phase+'/after-kill', before=art+'/'+phase+'/before-kill'
 const ws=await workspace(root)
 let latest
 for(const id of await ws.experiments()){
  const record=JSON.parse(readFileSync(before+'/experiments/'+id+'/manifest.json','utf8'))
  const r=await ws.recover(id);assert.ok(r.record)
  assert.ok(r.record.manifest.committed_sim_time_s>=record.committed_sim_time_s)
  assert.equal(r.record.result.formal_acceptance,'not_eligible')
  for(const e of [record.config,record.snapshot,record.result,...record.batches.flatMap(b=>b.files)]){
   const rel='/experiments/'+id+'/'+e.path,a=readFileSync(before+rel),b=readFileSync(root+rel)
   assert.deepEqual(a,b)
   assert.equal(createHash('sha256').update(b).digest('hex'),e.sha256)
   assert.equal(b.length,e.byte_length)
  }
  const selected=r.record.manifest
  for(const e of [selected.config,selected.snapshot,selected.result,...selected.batches.flatMap(b=>b.files)]){
   const bytes=readFileSync(root+'/experiments/'+id+'/'+e.path)
   assert.equal(createHash('sha256').update(bytes).digest('hex'),e.sha256)
   assert.equal(bytes.length,e.byte_length)
  }
  if(id === {'temp-before-close':'84ea1526-f7c5-4b7c-91f4-bb6b87e6a6a9','manifest-before-close':'89e92937-0d2d-4c40-afb0-60543137b8ca','committed-before-readback':'d568b703-6e2c-4fe4-8d15-de875d1f39f3'}[phase])latest={id,before:record.committed_sim_time_s,recovery:r.diagnostics,samples:r.record.output.samples.length}
 }
 results.push({phase,status:'passed',...latest})
}
for(const scenario of ['capacity-after-fault','capacity-after-retry']){
 const ws=await workspace(art+'/'+scenario)
 for(const id of await ws.experiments()){
  const r=await ws.recover(id);assert.ok(r.record)
  results.push({scenario,id,status:r.diagnostics.status,confirmed_sim_time_s:r.diagnostics.confirmed_sim_time_s,samples:r.record.output.samples.length})
 }
}
writeFileSync(art+'/independent-verification.json',JSON.stringify(results,null,2)+'\n')
process.stdout.write(JSON.stringify(results,null,2)+'\n')
