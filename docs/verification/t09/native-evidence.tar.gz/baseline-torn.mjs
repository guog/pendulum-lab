import {openWorkspace} from '/tmp/pendulum-14-baseline/src/workspace.ts'
import {createConfig} from '/tmp/pendulum-14-baseline/src/session.ts'
import assert from 'node:assert/strict'
const data=new Map()
const files={permission:async()=>true,list:async(path)=>[...new Set([...data.keys()].filter(k=>k.startsWith(path?path+'/':'')).map(k=>k.slice(path?path.length+1:0).split('/')[0]))],read:async(path)=>{if(!data.has(path))throw Error('missing');return data.get(path)},write:async(path,text)=>{data.set(path,text)}}
const workspace=await openWorkspace(files),run=await workspace.create(createConfig('standard','equilibrium'))
await run.start();await run.advance(.5)
const confirmed=await workspace.load(run.id),old=[...data].filter(([p])=>!p.startsWith('tmp/')&&!p.endsWith('manifest.json'))
const write=files.write
files.write=async(path,text)=>{if(path.endsWith('/manifest.json')){data.set(path,'{"torn":');throw Error('controlled torn overwrite')}return write(path,text)}
await assert.rejects(run.advance(.5),/torn/)
let failure
try{await workspace.load(run.id)}catch(error){failure=String(error)}
assert.match(failure,/SyntaxError/)
for(const [path,text] of old)assert.equal(data.get(path),text)
console.log(JSON.stringify({baseline:'5074fce45de89efe220fddd18adb8ca66aeef78a',confirmed_sim_time_s:confirmed.manifest.committed_sim_time_s,original_files_preserved:true,reopen_failed:failure,scope:'deterministic adapter; not Chrome proof'},null,2))
