import {createBrowser} from '/Users/guog/.codex/worktrees/110c/pendulum-lab/scripts/browser-driver.mjs'
import {readFileSync,writeFileSync,readdirSync,statSync,cpSync} from 'node:fs'
import assert from 'node:assert/strict'
const art='/tmp/pendulum-14-evidence/native/',id='e13919f3-b5b5-4a44-a89c-1a20d9356a4f'
const b=createBrowser('pendulum14',[],art+'scan-browser-steps.jsonl')
b('select','#workspace-history',id);b('click','#workspace-load')
b('wait','--fn',`document.querySelector('#workspace-diagnostics').textContent.includes('${id}')`)
const diagnostics=JSON.parse(b('get','text','#workspace-diagnostics'))
assert.equal(diagnostics.status,'sealed')
assert.equal(diagnostics.confirmed_sim_time_s,4)
assert.ok(diagnostics.scan_failures.some(f=>f.path==='diagnostics'&&f.error.includes('TypeMismatchError')))
assert.ok(diagnostics.orphan_files.includes('diagnostics'))
b('click','#workspace-export');await new Promise(r=>setTimeout(r,500))
const file=readdirSync('/Users/guog/Downloads').filter(n=>n.startsWith('recovery-'+id)&&n.endsWith('.json')).sort((a,z)=>statSync('/Users/guog/Downloads/'+z).mtimeMs-statSync('/Users/guog/Downloads/'+a).mtimeMs)[0]
const exported=JSON.parse(readFileSync('/Users/guog/Downloads/'+file,'utf8'))
assert.equal(exported.recovery.record.output.samples.length,401)
assert.deepEqual(exported.recovery.diagnostics,diagnostics)
assert.equal(readFileSync('/tmp/pendulum-14-native/experiments/'+id+'/diagnostics','utf8'),'unreferenced diagnostic placeholder\n')
writeFileSync(art+'scan-browser-export.json',JSON.stringify(exported,null,2))
writeFileSync(art+'scan-browser-result.json',JSON.stringify({status:'passed',diagnostics,build:JSON.parse(readFileSync('/Users/guog/.codex/worktrees/110c/pendulum-lab/dist/build-info.json','utf8'))},null,2))
b('screenshot',art+'scan-browser.png')
cpSync('/tmp/pendulum-14-native/experiments/'+id,art+'scan-experiment',{recursive:true})
console.log('real FSA TypeMismatchError scan does not block sealed history or export')
