import {createBrowser} from '/Users/guog/.codex/worktrees/110c/pendulum-lab/scripts/browser-driver.mjs'
import {writeFileSync,readFileSync,cpSync,readdirSync,statSync,chmodSync} from 'node:fs'
import assert from 'node:assert/strict'
const art='/tmp/pendulum-14-evidence/native/', root='/tmp/pendulum-14-native'
const b=createBrowser('pendulum14',[],art+'final-browser-steps.jsonl')
b('click','#workspace-load')
b('wait','--fn','document.querySelector("#workspace-diagnostics").textContent.includes("workspace_orphan_files")')
const initial=JSON.parse(b('get','text','#workspace-diagnostics'))
assert.ok(initial.workspace_orphan_files.includes('tmp/pending.json'))
b('click','#workspace-start')
b('wait','--fn','/已确认 (?:[1-9]|0\.[5-9])/.test(document.querySelector("#workspace-progress").textContent)')
const live=b('get','value','#workspace-history')
assert.notEqual(live,initial.experiment_id)
const dir=root+'/experiments/'+live
const directories=()=>{const found=[dir];function walk(path){for(const n of readdirSync(path)){const p=path+'/'+n;if(statSync(p).isDirectory()){found.push(p);walk(p)}}}walk(dir);return found}
const modified=directories()
try{
 for(const p of modified)chmodSync(p,0o555)
 b('wait','--fn','document.querySelector("#workspace-error").textContent.includes("NoModificationAllowedError")')
 const frozen=b('get','text','#workspace-progress')
 b('select','#workspace-history',initial.experiment_id)
 b('click','#workspace-load')
 b('wait','--fn',`JSON.parse(document.querySelector('#workspace-diagnostics').textContent).experiment_id === '${initial.experiment_id}'`)
 assert.equal(b('get','value','#workspace-history'),initial.experiment_id)
 b('click','#workspace-export')
 await new Promise(r=>setTimeout(r,500))
 const existing='/Users/guog/Downloads/recovery-'+initial.experiment_id+'.json'
 // Chrome may suffix repeated filenames; select the newest matching download.
 const stem='recovery-'+initial.experiment_id
 const download=readdirSync('/Users/guog/Downloads').filter(p=>p.startsWith(stem)&&p.endsWith('.json')).sort((a,z)=>statSync('/Users/guog/Downloads/'+z).mtimeMs-statSync('/Users/guog/Downloads/'+a).mtimeMs)[0]
 const exported=JSON.parse(readFileSync('/Users/guog/Downloads/'+download,'utf8'))
 assert.equal(exported.recovery.diagnostics.experiment_id,initial.experiment_id)
 writeFileSync(art+'final-selected-history-export.json',JSON.stringify(exported,null,2))
 b('select','#workspace-history',live)
 b('click','#workspace-load')
 b('wait','--fn',`JSON.parse(document.querySelector('#workspace-diagnostics').textContent).experiment_id === '${live}'`)
 const diagnosed=JSON.parse(b('get','text','#workspace-diagnostics'))
 assert.equal(diagnosed.live_fault.storage_fault.name,'NoModificationAllowedError')
 assert.ok(diagnosed.workspace_orphan_files.includes('tmp/pending.json'))
 assert.equal(b('get','text','#workspace-progress'),frozen)
 writeFileSync(art+'final-fault-diagnostics.json',JSON.stringify(diagnosed,null,2))
 b('screenshot',art+'final-fault.png')
}finally{for(const p of modified)chmodSync(p,0o755)}
b('click','#workspace-retry')
b('wait','--fn','!document.querySelector("#workspace-stop").disabled')
b('click','#workspace-stop')
b('wait','--fn','document.querySelector("#workspace-record").textContent.includes("sealed-verified")')
writeFileSync(art+'final-browser-result.json',JSON.stringify({status:'passed',live,initial:initial.experiment_id,build:JSON.parse(readFileSync('/Users/guog/.codex/worktrees/110c/pendulum-lab/dist/build-info.json','utf8')),coverage:['global-temporary-diagnostics','default-current-history','explicit-other-history-retained-after-worker-list','export-matches-selected-history','actual-readonly-freeze','retry-seal']},null,2))
cpSync(root,art+'final-workspace',{recursive:true})
console.log('final browser boundaries passed')
