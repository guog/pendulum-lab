import {readFileSync,writeFileSync,cpSync,mkdirSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
const [pidText, profile, phase] = process.argv.slice(2), pid=Number(pidText)
const port=readFileSync(profile+'/DevToolsActivePort','utf8').trim().split('\n')[0]
const targets=await (await fetch(`http://localhost:${port}/json/list`)).json()
const worker=targets.find(t=>t.type==='worker'&&t.url.includes('workspace.worker-'))
if(!worker)throw Error('missing workspace worker')
const socket=new WebSocket(worker.webSocketDebuggerUrl)
await new Promise((resolve,reject)=>{socket.onopen=resolve;socket.onerror=reject})
let id=0;const pending=new Map();const events=[]
socket.onmessage=({data})=>{const m=JSON.parse(data);if(m.id){pending.get(m.id)?.(m);pending.delete(m.id)}else events.push(m)}
async function send(method,params={}){return new Promise((resolve,reject)=>{const key=++id;pending.set(key,m=>m.error?reject(Error(JSON.stringify(m.error))):resolve(m.result));socket.send(JSON.stringify({id:key,method,params}))})}
await send('Debugger.enable')
const parsed=events.find(e=>e.method==='Debugger.scriptParsed'&&e.params.url===worker.url)
if(!parsed)throw Error('missing script')
const {scriptSource:source}=await send('Debugger.getScriptSource',{scriptId:parsed.params.scriptId})
const cutPhase=phase.replace(/^final-/, '')
const needle=cutPhase==='temp-before-close'?'await n.close()':cutPhase==='manifest-before-close'?'await n.close()':'await e.read(t)!==n'
const offset=source.indexOf(needle)
if(offset<0)throw Error('source position unavailable')
const lines=source.slice(0,offset).split('\n')
const condition=cutPhase==='temp-before-close'?"e === 'tmp/pending.json'":cutPhase==='manifest-before-close'?"e.endsWith('/manifest.json')":"t.includes('/confirmed/manifest-')"
const runVariable = source.match(/let (\w+),(\w+),(\w+),(\w+)=Promise.resolve\(\)/)?.[2]
if(!runVariable)throw Error('Cannot locate worker run variable')
const guardedCondition = '('+condition+') && '+runVariable+'?.progress().committed_sim_time_s >= 0.5 && '+runVariable+'?.progress().status === \'running\''
const breakpoint=await send('Debugger.setBreakpoint',{location:{scriptId:parsed.params.scriptId,lineNumber:lines.length-1,columnNumber:lines.at(-1).length},condition:guardedCondition})
writeFileSync(`/tmp/pendulum-14-evidence/native/${phase}-armed.json`,JSON.stringify({worker,needle,condition,breakpoint},null,2))
process.stdout.write('ARMED '+phase+'\n')
let paused
for(let i=0;i<1200;i++){
 paused=events.find(e=>e.method==='Debugger.paused');if(paused)break
 await new Promise(r=>setTimeout(r,50))
}
if(!paused)throw Error('No breakpoint within 60s')
const page=targets.find(t=>t.type==='page'&&t.url==='http://localhost:5194/')
// Snapshot disk while the real Worker is paused at an actual native FSA boundary.
const root=`/tmp/pendulum-14-evidence/native/${phase}`
mkdirSync(root,{recursive:true});cpSync('/tmp/pendulum-14-native',root+'/before-kill',{recursive:true})
const processes=execFileSync('ps',['-axo','pid,ppid,command'],{encoding:'utf8'}).split('\n').map(line=>line.trim().match(/^(\d+)\s+(\d+)\s+(.*)$/)).filter(Boolean).map(m=>({pid:Number(m[1]),ppid:Number(m[2]),command:m[3]}))
const browser=processes.find(p=>p.pid===pid)
if(!browser?.command.includes('--user-data-dir='+profile))throw Error('Test process identity mismatch')
const descendants=new Set([pid]);for(let n=0;n<8;n++)for(const p of processes)if(descendants.has(p.ppid))descendants.add(p.pid)
writeFileSync(root+'/cut.json',JSON.stringify({phase,page,paused,processes:processes.filter(p=>descendants.has(p.pid)),time:new Date().toISOString()},null,2))
for(const child of [...descendants].reverse())try{process.kill(child,'SIGKILL')}catch{}
await new Promise(r=>setTimeout(r,300));cpSync('/tmp/pendulum-14-native',root+'/after-kill',{recursive:true})
process.stdout.write('KILLED '+phase+'\n');socket.close()
