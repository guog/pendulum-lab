import {setup,browser,json,sourceIdentity,preserveManifest,exportReadback,chromeProcess} from './common.mjs'
import {readFileSync,cpSync,statSync,statfsSync} from 'node:fs'
import assert from 'node:assert/strict'
const out=setup.evidence+'/permission-revocation',before=JSON.parse(readFileSync(out+'/before.json','utf8')),id=before.id
sourceIdentity();browser('wait','--fn','document.querySelector("#workspace-error").textContent.includes("NotAllowedError")')
const error=browser('get','text','#workspace-error'),progress=browser('get','text','#workspace-progress')
assert.match(progress,/状态 paused/);assert.equal(browser('is','enabled','#workspace-resume'),'false');assert.equal(browser('is','enabled','#workspace-stop'),'false')
const storageFault=JSON.parse(browser('get','text','#workspace-diagnostics'));assert.equal(storageFault.name,'NotAllowedError')
assert.equal(statSync(setup.workspace).mode,before.mode)
const confirmed=JSON.parse(readFileSync(setup.workspace+'/experiments/'+id+'/manifest.json','utf8'))
assert.equal(confirmed.committed_sim_time_s,storageFault.committed_sim_time_s)
assert.ok(storageFault.sim_time_s-storageFault.committed_sim_time_s<=1)
preserveManifest(setup.workspace,id,confirmed);preserveManifest(setup.workspace,id,before.manifest)
for(const e of [before.manifest.config,before.manifest.snapshot,before.manifest.result,...before.manifest.batches.flatMap(b=>b.files)])assert.deepEqual(readFileSync(out+'/before-revocation/experiments/'+id+'/'+e.path),readFileSync(setup.workspace+'/experiments/'+id+'/'+e.path))
json(out+'/native-action.json',{tool:'cua_repl',observed_window:'此页面可修改文件',observed_text:'http://localhost:5197 可修改“workspace”内的文件',control:'撤消访问权限',action:'Clicked observed native button at popup-local coordinates 250,264 after opening the observed file-access chip at 2046,126',effect:error,recorded_at_utc:new Date().toISOString()})
json(out+'/frozen.json',{id,error,progress,storageFault,confirmed,mode:statSync(setup.workspace).mode,space:statfsSync(setup.workspace),build:setup.identity})
browser('screenshot',out+'/frozen.png')
browser('click','#workspace-load')
browser('wait','--fn',`document.querySelector('#workspace-diagnostics').textContent.includes('${id}')`)
const diagnostics=JSON.parse(browser('get','text','#workspace-diagnostics'))
const exported=await exportReadback(id,out+'/denied-access-download.json')
assert.equal(exported.live_fault.storage_fault.name,'NotAllowedError')
assert.equal(exported.live_fault.output.config.execution_mode,'authorized-directory')
assert.equal(browser('get','text','#workspace-progress'),progress)
json(out+'/denied-read-diagnostics.json',diagnostics)
cpSync(setup.workspace,out+'/after-revocation',{recursive:true})
// Restart this dedicated test browser without attempting to continue the revoked run.
const p=chromeProcess(),descendants=new Set([p.pid]);for(let i=0;i<8;i++)for(const item of p.processes)if(descendants.has(item.ppid))descendants.add(item.pid)
json(out+'/error-close-processes.json',p.processes.filter(item=>descendants.has(item.pid)))
for(const pid of [...descendants].reverse())try{process.kill(pid,'SIGKILL')}catch{}
console.log('actual directory permission revoked: '+id+' '+storageFault.sim_time_s+'/'+storageFault.committed_sim_time_s)
