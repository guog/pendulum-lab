import {setup,browser,json,sourceIdentity} from './common.mjs'
import {readFileSync,mkdirSync,cpSync,statSync} from 'node:fs'
const out=setup.evidence+'/permission-live-export';mkdirSync(out)
json(out+'/source.json',sourceIdentity())
const old=browser('get','value','#workspace-history');browser('click','#workspace-start')
browser('wait','--fn',`document.querySelector('#workspace-progress').textContent.includes('状态 running') && document.querySelector('#workspace-history').value !== '${old}' && Number(document.querySelector('#workspace-progress').textContent.match(/已确认 ([0-9.]+)/)[1]) >= .5`)
const id=browser('get','value','#workspace-history'),manifest=JSON.parse(readFileSync(setup.workspace+'/experiments/'+id+'/manifest.json','utf8'))
cpSync(setup.workspace+'/experiments/'+id,out+'/before-experiment',{recursive:true})
json(out+'/before.json',{id,manifest,progress:browser('get','text','#workspace-progress'),mode:statSync(setup.workspace).mode,time:new Date().toISOString()})
console.log('READY '+id)
