import {setup,browser,json,sourceIdentity,preserveManifest,exportReadback} from './common.mjs'
import {readFileSync,mkdirSync,cpSync,openSync,writeSync,fsyncSync,closeSync,unlinkSync,statfsSync,statSync} from 'node:fs'
import assert from 'node:assert/strict'
const root='/tmp/p14capacityCCIDze',workspace=root+'/workspace',out=setup.evidence+'/capacity';mkdirSync(out)
json(out+'/source.json',sourceIdentity());assert.match(browser('get','text','#workspace-identity'),/可写/)
const oldId=browser('get','value','#workspace-history')
browser('click','#workspace-start')
browser('wait','--fn',`document.querySelector('#workspace-progress').textContent.includes('状态 running') && document.querySelector('#workspace-history').value !== '${oldId}' && Number(document.querySelector('#workspace-progress').textContent.match(/已确认 ([0-9.]+)/)[1]) >= .5`)
const id=browser('get','value','#workspace-history'),prefix=workspace+'/experiments/'+id,before=JSON.parse(readFileSync(prefix+'/manifest.json','utf8'))
cpSync(workspace,out+'/before-fill',{recursive:true})
const beforeMode=statSync(workspace).mode,spaceBefore=statfsSync(root),filler=root+'/capacity-filler.bin',fd=openSync(filler,'w'),failures=[]
let filled=0
try{
 for(const size of [1024*1024,4096]){
  const buffer=Buffer.alloc(size,0x5a)
  try{for(let i=0;i<12800;i++){writeSync(fd,buffer);filled+=size}}
  catch(error){failures.push({name:error.name,code:error.code,message:error.message});assert.equal(error.code,'ENOSPC')}
 }
 try{fsyncSync(fd)}catch(error){failures.push({name:error.name,code:error.code,message:error.message});assert.equal(error.code,'ENOSPC')}
}finally{closeSync(fd)}
json(out+'/fill-action.json',{id,spaceBefore,spaceFull:statfsSync(root),filled,failures,before,mode:beforeMode})
assert.ok(failures.length)
let frozen,diagnostics,originalError
try{
 browser('wait','--fn','document.querySelector("#workspace-error").textContent.length>0')
 originalError=browser('get','text','#workspace-error');frozen=browser('get','text','#workspace-progress')
 assert.match(frozen,/状态 paused/);assert.equal(browser('is','enabled','#workspace-resume'),'false');assert.equal(browser('is','enabled','#workspace-stop'),'false')
 assert.equal(statSync(workspace).mode,beforeMode)
 browser('click','#workspace-load');browser('wait','--fn',`document.querySelector('#workspace-diagnostics').textContent.includes('${id}')`)
 diagnostics=JSON.parse(browser('get','text','#workspace-diagnostics'))
 assert.ok(diagnostics.live_fault.storage_fault.name);assert.notEqual(diagnostics.live_fault.storage_fault.name,'NotAllowedError')
 assert.ok(originalError.includes(diagnostics.live_fault.storage_fault.name))
 assert.ok(diagnostics.live_fault.storage_fault.sim_time_s-diagnostics.live_fault.storage_fault.committed_sim_time_s<=1)
 const exported=await exportReadback(id,out+'/frozen-download.json');assert.equal(exported.live_fault.storage_fault.name,diagnostics.live_fault.storage_fault.name)
 assert.equal(browser('get','text','#workspace-progress'),frozen)
 preserveManifest(workspace,id,before)
 for(const entry of [before.config,before.snapshot,before.result,...before.batches.flatMap(b=>b.files)])assert.deepEqual(readFileSync(out+'/before-fill/experiments/'+id+'/'+entry.path),readFileSync(prefix+'/'+entry.path))
 browser('screenshot',out+'/frozen.png');cpSync(workspace,out+'/after-fault',{recursive:true});json(out+'/frozen.json',{originalError,frozen,diagnostics})
}finally{unlinkSync(filler)}
browser('click','#workspace-retry');browser('wait','--fn','!document.querySelector("#workspace-stop").disabled')
assert.match(browser('get','text','#workspace-progress'),/状态 paused/)
browser('click','#workspace-stop');browser('wait','--fn','document.querySelector("#workspace-record").textContent.includes("sealed-verified")')
const manifest=JSON.parse(readFileSync(prefix+'/manifest.json','utf8'));assert.equal(manifest.sealed,true);preserveManifest(workspace,id,manifest)
const finalEvents=manifest.batches.flatMap(batch=>readFileSync(prefix+'/'+batch.files[1].path,'utf8').trim().split('\n').filter(Boolean).map(line=>JSON.parse(line)))
assert.ok(finalEvents.some(e=>e.event_type==='storage_error'))
assert.equal(manifest.sample_count,Math.round(diagnostics.live_fault.output.sim_time_s/.01)+1)
cpSync(workspace,out+'/after-retry',{recursive:true});browser('screenshot',out+'/sealed.png')
json(out+'/result.json',{status:'passed',id,build:setup.identity,os_error:'ENOSPC',chrome_error:diagnostics.live_fault.storage_fault.name,frozen_sim_time_s:diagnostics.live_fault.output.sim_time_s,confirmed_sim_time_s:diagnostics.live_fault.committed_sim_time_s,sealed_sim_time_s:manifest.committed_sim_time_s,samples:manifest.sample_count,actual_error:originalError,diagnostics,sealed_manifest:manifest})
console.log('capacity failure, frozen export, retry and sealing passed '+id+' '+diagnostics.live_fault.storage_fault.name)
