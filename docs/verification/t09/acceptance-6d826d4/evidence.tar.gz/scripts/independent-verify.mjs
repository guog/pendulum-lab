import {setup,json} from './common.mjs'
import {readFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import assert from 'node:assert/strict'
const plan=[
 ['temp-before-close','after-native-reopen',51],
 ['manifest-before-close','after-native-reopen',101],
 ['committed-before-readback','after-native-reopen',101],
 ['permission-revocation','after-native-reauthorization',501],
 ['capacity','after-retry',301],
 ['readonly','after-retry',1001],
]
const checks=[]
for(const [scenario,tree,expected] of plan){
 const out=setup.evidence+'/'+scenario,result=JSON.parse(readFileSync(out+'/result.json','utf8')),id=result.id,root=out+'/'+tree+'/experiments/'+id
 assert.equal(result.status,'passed');assert.deepEqual(result.build,setup.identity)
 let manifest
 if(scenario==='manifest-before-close'||scenario==='committed-before-readback')manifest=JSON.parse(readFileSync(out+'/download.json','utf8')).recovery.record.manifest
 else manifest=JSON.parse(readFileSync(root+'/manifest.json','utf8'))
 const entries=[manifest.config,manifest.snapshot,manifest.result,...manifest.batches.flatMap(batch=>batch.files)]
 for(const e of entries){const data=readFileSync(root+'/'+e.path);assert.equal(data.length,e.byte_length);assert.equal(createHash('sha256').update(data).digest('hex'),e.sha256)}
 const config=JSON.parse(readFileSync(root+'/'+manifest.config.path,'utf8'));assert.deepEqual(config.build_identity,setup.identity);assert.equal(config.experiment_id,id)
 const period=config.timing.sample_period_s,samples=[],events=[]
 for(const batch of manifest.batches){
  const lines=readFileSync(root+'/'+batch.files[0].path,'utf8').trimEnd().split('\n'),columns=lines.shift().split(',')
  assert.equal(columns[0],'sample_index');assert.equal(columns[1],'sim_time_s');assert.ok(columns.includes('theta_unwrapped_rad'))
  for(const line of lines){if(!line)continue;const cells=line.split(',');assert.equal(cells.length,columns.length);samples.push({index:Number(cells[0]),time:Number(cells[1])})}
  const text=readFileSync(root+'/'+batch.files[1].path,'utf8').trim();if(text)events.push(...text.split('\n').map(line=>JSON.parse(line)))
 }
 assert.equal(samples.length,expected);assert.equal(samples.length,manifest.sample_count)
 for(let i=0;i<samples.length;i++){assert.equal(samples[i].index,i);assert.ok(Math.abs(samples[i].time-i*period)<1e-10)}
 for(let i=0;i<events.length;i++){assert.equal(events[i].event_index,i);assert.equal(events[i].experiment_id,id)}
 assert.equal(events.length,manifest.event_count)
 const stored=JSON.parse(readFileSync(root+'/'+manifest.result.path,'utf8'));assert.equal(stored.formal_acceptance,'not_eligible')
 if(scenario==='capacity'||scenario==='readonly')assert.ok(events.some(e=>e.event_type==='storage_error'))
 checks.push({scenario,status:'passed',experiment_id:id,samples:expected,sample_period_s:period,confirmed_sim_time_s:manifest.committed_sim_time_s,files_checked:entries.length,events:events.length,build:config.build_identity})
}
json(setup.evidence+'/independent-verification.json',{status:'passed',basis:'Node fs and crypto; literal expected sample counts; no application loader or sample-column constants imported',checks})
console.log('independent file contract and prefix checks: '+checks.length+' passed')
