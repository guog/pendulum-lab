import {setup,browser,json,sourceIdentity} from './common.mjs'
import {readFileSync,mkdirSync,cpSync,statSync,statfsSync} from 'node:fs'
const out=setup.evidence+'/permission-revocation';mkdirSync(out)
json(out+'/source.json',sourceIdentity())
browser('click','#workspace-start')
browser('wait','--fn','Number(document.querySelector("#workspace-progress").textContent.match(/已确认 ([0-9.]+)/)[1]) >= .5')
const id=browser('get','value','#workspace-history'),manifest=JSON.parse(readFileSync(setup.workspace+'/experiments/'+id+'/manifest.json','utf8'))
cpSync(setup.workspace,out+'/before-revocation',{recursive:true})
json(out+'/before.json',{id,manifest,progress:browser('get','text','#workspace-progress'),mode:statSync(setup.workspace).mode,space:statfsSync(setup.workspace),time:new Date().toISOString()})
console.log('READY '+id)
