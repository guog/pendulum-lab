
import {readFileSync,writeFileSync,readdirSync,statSync,cpSync} from 'node:fs'
import {execFileSync,spawnSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import assert from 'node:assert/strict'
import {createBrowser} from '/Users/guog/.codex/worktrees/110c/pendulum-lab/scripts/browser-driver.mjs'
export const setup=JSON.parse(readFileSync('/tmp/pendulum14-acceptance-current.json','utf8'))
export const browser=createBrowser(setup.session,[],setup.evidence+'/browser-steps.jsonl')
export const json=(path,value)=>writeFileSync(path,JSON.stringify(value,null,2)+'\n')
export function sourceIdentity(){
 const identity=JSON.parse(browser('get','text','#config')).build_identity
 assert.deepEqual(identity,setup.identity)
 return identity
}
export function chromeProcess(){
 const daemon=Number(readFileSync('/Users/guog/.agent-browser/'+setup.session+'.pid','utf8'))
 const processes=execFileSync('ps',['-axo','pid,ppid,command'],{encoding:'utf8'}).split('\n').map(line=>line.trim().match(/^(\d+)\s+(\d+)\s+(.*)$/)).filter(Boolean).map(m=>({pid:Number(m[1]),ppid:Number(m[2]),command:m[3]}))
 const chrome=processes.find(p=>p.ppid===daemon&&p.command.startsWith('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome --remote-debugging-port='))
 assert.ok(chrome,'dedicated Chrome process')
 return {...chrome,profile:chrome.command.match(/--user-data-dir=(\S+)/)[1],processes}
}
export async function connectWorker(){
 const process=chromeProcess(),port=readFileSync(process.profile+'/DevToolsActivePort','utf8').split('\n')[0]
 const targets=await(await fetch('http://localhost:'+port+'/json/list')).json()
 const worker=targets.find(t=>t.type==='worker'&&t.url.includes('workspace.worker-'))
 assert.ok(worker)
 const socket=new WebSocket(worker.webSocketDebuggerUrl)
 await new Promise((resolve,reject)=>{socket.onopen=resolve;socket.onerror=reject})
 let seq=0;const pending=new Map(),events=[]
 socket.onmessage=({data})=>{const m=JSON.parse(data);if(m.id){pending.get(m.id)?.(m);pending.delete(m.id)}else events.push(m)}
 const send=(method,params={})=>new Promise((resolve,reject)=>{const id=++seq;pending.set(id,m=>m.error?reject(Error(JSON.stringify(m.error))):resolve(m.result));socket.send(JSON.stringify({id,method,params}))})
 return {process,targets,worker,socket,events,send}
}
export function preserveManifest(root,id,manifest){
 const entries=[manifest.config,manifest.snapshot,manifest.result,...manifest.batches.flatMap(b=>b.files)]
 for(const e of entries){const bytes=readFileSync(root+'/experiments/'+id+'/'+e.path);assert.equal(bytes.length,e.byte_length);assert.equal(createHash('sha256').update(bytes).digest('hex'),e.sha256)}
}
export async function exportReadback(id,destination){
 browser('click','#workspace-export')
 let path
 for(let i=0;i<100;i++){
  const names=readdirSync('/Users/guog/Downloads').filter(n=>n.startsWith('recovery-'+id)&&n.endsWith('.json')).sort((a,b)=>statSync('/Users/guog/Downloads/'+b).mtimeMs-statSync('/Users/guog/Downloads/'+a).mtimeMs)
  if(names.length){path='/Users/guog/Downloads/'+names[0];break}
  await new Promise(r=>setTimeout(r,50))
 }
 assert.ok(path,'actual browser download')
 const result=JSON.parse(readFileSync(path,'utf8'));assert.equal(result.recovery.diagnostics.experiment_id,id)
 cpSync(path,destination)
 return result
}
export function openChrome(){const r=spawnSync('npx',['--yes','--package','agent-browser@0.41.1','agent-browser','--session',setup.session,'--headed','--executable-path','/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','open',setup.url],{encoding:'utf8'});if(r.status!==0)throw Error(r.stderr);return r.stdout}
