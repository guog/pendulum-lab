import {setup,browser,json,sourceIdentity,preserveManifest,exportReadback} from './common.mjs'
import {readFileSync,mkdirSync,cpSync,statSync,statfsSync,writeFileSync} from 'node:fs'
import assert from 'node:assert/strict'
const out=setup.evidence+'/permission-revocation';mkdirSync(out)
const tabs=JSON.parse(browser('tab','list','--json')).data.tabs
const app=tabs.find(t=>t.url===setup.url),settings=tabs.find(t=>t.url.startsWith('chrome://settings/content/siteDetails'))
assert.ok(app&&settings)
json(out+'/tabs.json',{app,settings})
browser('tab',app.tabId);json(out+'/source.json',sourceIdentity())
browser('click','#workspace-start')
browser('wait','--fn','Number(document.querySelector("#workspace-progress").textContent.match(/已确认 ([0-9.]+)/)[1]) >= .5')
const id=browser('get','value','#workspace-history'),prefix=setup.workspace+'/experiments/'+id
const before=JSON.parse(readFileSync(prefix+'/manifest.json','utf8'))
cpSync(setup.workspace,out+'/before-revocation',{recursive:true})
json(out+'/before.json',{id,progress:browser('get','text','#workspace-progress'),mode:statSync(setup.workspace).mode,space:statfsSync(setup.workspace),manifest:before})
browser('tab',settings.tabId)
let snapshot=browser('snapshot','-i'),ref='@'+snapshot.match(/combobox "文件修改"[^\n]*ref=(e\d+)/)[1]
json(out+'/setting-before.json',{snapshot,select:browser('get','html',ref),value:browser('get','value',ref)})
browser('select',ref,'block')
snapshot=browser('snapshot','-i');ref='@'+snapshot.match(/combobox "文件修改"[^\n]*ref=(e\d+)/)[1]
assert.equal(browser('get','value',ref),'block')
json(out+'/setting-revoked.json',{snapshot,value:browser('get','value',ref)})
browser('screenshot',out+'/chrome-file-modification-blocked.png')
browser('tab',app.tabId)
const initialError=browser('get','text','#workspace-error')
if(!initialError){
 browser('wait','--fn','!document.querySelector("#workspace-resume").disabled || document.querySelector("#workspace-error").textContent.length > 0')
 if(!browser('get','text','#workspace-error'))browser('click','#workspace-resume')
}
browser('wait','--fn','document.querySelector("#workspace-error").textContent.length > 0')
const error=browser('get','text','#workspace-error'),progress=browser('get','text','#workspace-progress')
json(out+'/error.json',{error,progress,mode:statSync(setup.workspace).mode,space:statfsSync(setup.workspace)})
assert.match(error,/NotAllowedError/)
assert.match(progress,/状态 paused/)
assert.equal(browser('is','enabled','#workspace-resume'),'false')
assert.equal(browser('is','enabled','#workspace-stop'),'false')
browser('click','#workspace-load');browser('wait','--fn',`document.querySelector('#workspace-diagnostics').textContent.includes('${id}')`)
const diagnostics=JSON.parse(browser('get','text','#workspace-diagnostics'))
assert.equal(diagnostics.live_fault.storage_fault.name,'NotAllowedError')
assert.ok(diagnostics.confirmed_sim_time_s>=before.committed_sim_time_s)
const exported=await exportReadback(id,out+'/download.json')
preserveManifest(setup.workspace,id,before)
for(const entry of [before.config,before.snapshot,before.result,...before.batches.flatMap(b=>b.files)])assert.deepEqual(readFileSync(out+'/before-revocation/experiments/'+id+'/'+entry.path),readFileSync(prefix+'/'+entry.path))
browser('screenshot',out+'/frozen.png');cpSync(setup.workspace,out+'/after-revocation',{recursive:true})
json(out+'/result.json',{status:'passed',id,error,progress,diagnostics,build:setup.identity,method:'Chrome per-site File Modification permission changed from default/ask to block; no OS permissions or disk capacity changed'})
console.log('Chrome permission revocation passed '+id+' '+error)
