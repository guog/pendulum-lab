import {setup,browser,json,sourceIdentity,preserveManifest,exportReadback} from './common.mjs'
import {readFileSync,mkdirSync,cpSync,readdirSync,statSync,chmodSync} from 'node:fs'
import assert from 'node:assert/strict'
const workspace='/tmp/p14capacityCCIDze/workspace',out=setup.evidence+'/readonly';mkdirSync(out)
json(out+'/source.json',sourceIdentity());browser('select','#workspace-sampling','0.001')
const old=browser('get','value','#workspace-history');browser('click','#workspace-start')
browser('wait','--fn',`document.querySelector('#workspace-progress').textContent.includes('状态 running') && document.querySelector('#workspace-history').value !== '${old}' && Number(document.querySelector('#workspace-progress').textContent.match(/已确认 ([0-9.]+)/)[1]) >= .5`)
const id=browser('get','value','#workspace-history'),prefix=workspace+'/experiments/'+id,before=JSON.parse(readFileSync(prefix+'/manifest.json','utf8'))
cpSync(workspace,out+'/before-readonly',{recursive:true})
const paths=[];function walk(path){paths.push({path,mode:statSync(path).mode&0o7777});for(const name of readdirSync(path)){const next=path+'/'+name;if(statSync(next).isDirectory())walk(next)}}walk(prefix)
json(out+'/chmod-action.json',{id,mode:'0555',paths,before})
let diagnostics,error,frozen
try{
 for(const p of paths)chmodSync(p.path,0o555)
 browser('wait','--fn','document.querySelector("#workspace-error").textContent.includes("NoModificationAllowedError")')
 error=browser('get','text','#workspace-error');frozen=browser('get','text','#workspace-progress')
 assert.equal(browser('is','enabled','#workspace-resume'),'false');assert.equal(browser('is','enabled','#workspace-stop'),'false')
 browser('click','#workspace-load');browser('wait','--fn',`document.querySelector('#workspace-diagnostics').textContent.includes('${id}')`)
 diagnostics=JSON.parse(browser('get','text','#workspace-diagnostics'));assert.equal(diagnostics.live_fault.storage_fault.name,'NoModificationAllowedError')
 assert.equal(diagnostics.live_fault.output.config.timing.sample_period_s,.001)
 assert.ok(diagnostics.live_fault.storage_fault.sim_time_s-diagnostics.live_fault.storage_fault.committed_sim_time_s<=1)
 await exportReadback(id,out+'/download.json');assert.equal(browser('get','text','#workspace-progress'),frozen)
 preserveManifest(workspace,id,before)
 for(const entry of [before.config,before.snapshot,before.result,...before.batches.flatMap(b=>b.files)])assert.deepEqual(readFileSync(out+'/before-readonly/experiments/'+id+'/'+entry.path),readFileSync(prefix+'/'+entry.path))
 browser('screenshot',out+'/frozen.png');cpSync(workspace,out+'/after-fault',{recursive:true})
}finally{for(const p of paths)chmodSync(p.path,p.mode)}
browser('click','#workspace-retry');browser('wait','--fn','!document.querySelector("#workspace-stop").disabled');assert.match(browser('get','text','#workspace-progress'),/状态 paused/)
browser('click','#workspace-stop');browser('wait','--fn','document.querySelector("#workspace-record").textContent.includes("sealed-verified")')
const sealed=JSON.parse(readFileSync(prefix+'/manifest.json','utf8'));preserveManifest(workspace,id,sealed);assert.equal(sealed.sample_count,Math.round(diagnostics.live_fault.output.sim_time_s/.001)+1)
const events=sealed.batches.flatMap(batch=>readFileSync(prefix+'/'+batch.files[1].path,'utf8').trim().split('\n').filter(Boolean).map(line=>JSON.parse(line)))
assert.ok(events.some(e=>e.event_type==='storage_error'))
cpSync(workspace,out+'/after-retry',{recursive:true});browser('screenshot',out+'/sealed.png')
json(out+'/result.json',{status:'passed',id,build:setup.identity,error,sample_period_s:.001,frozen_sim_time_s:diagnostics.live_fault.output.sim_time_s,confirmed_sim_time_s:diagnostics.live_fault.committed_sim_time_s,sealed_sim_time_s:sealed.committed_sim_time_s,samples:sealed.sample_count,diagnostics,sealed_manifest:sealed,restored_modes:paths})
console.log('readonly 1ms recording failure, export and retry passed '+id)
