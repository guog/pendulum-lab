
import {setup,browser,json,sourceIdentity,preserveManifest,exportReadback} from './common.mjs'
import {readFileSync,cpSync} from 'node:fs'
import assert from 'node:assert/strict'
const phase=process.argv[2],out=setup.evidence+'/'+phase
const {progress}=JSON.parse(readFileSync(out+'/paused.json','utf8')),id=progress.experiment_id
sourceIdentity();browser('select','#workspace-history',id);browser('click','#workspace-load')
browser('wait','--fn',"document.querySelector('#workspace-diagnostics').textContent.includes('"+id+"')")
const diagnostics=JSON.parse(browser('get','text','#workspace-diagnostics'))
assert.equal(diagnostics.status,'interrupted');assert.ok(diagnostics.confirmed_sim_time_s>=progress.committed_sim_time_s)
assert.equal(diagnostics.unconfirmed_tail.end_sim_time_s,null);assert.equal(browser('is','enabled','#workspace-resume'),'false')
const exported=await exportReadback(id,out+'/download.json'),record=exported.recovery.record
assert.equal(record.result.formal_acceptance,'not_eligible')
assert.equal(record.output.samples.length,Math.round(record.manifest.committed_sim_time_s/.01)+1)
for(let i=0;i<record.output.samples.length;i++){assert.equal(record.output.samples[i].sample_index,i);assert.ok(Math.abs(record.output.samples[i].sim_time_s-i*.01)<1e-12)}
const acknowledged=JSON.parse(readFileSync(out+'/before-kill/experiments/'+id+'/manifest.json','utf8'))
assert.equal(acknowledged.committed_sim_time_s,progress.committed_sim_time_s)
preserveManifest(out+'/before-kill',id,acknowledged);preserveManifest(out+'/after-kill',id,acknowledged);preserveManifest(setup.workspace,id,record.manifest)
for(const e of [acknowledged.config,acknowledged.snapshot,acknowledged.result,...acknowledged.batches.flatMap(b=>b.files)])assert.deepEqual(readFileSync(out+'/before-kill/experiments/'+id+'/'+e.path),readFileSync(out+'/after-kill/experiments/'+id+'/'+e.path))
browser('screenshot',out+'/recovered.png');cpSync(setup.workspace,out+'/after-native-reopen',{recursive:true})
json(out+'/result.json',{status:'passed',phase,id,acknowledged_sim_time_s:progress.committed_sim_time_s,recovered_sim_time_s:record.manifest.committed_sim_time_s,samples:record.output.samples.length,diagnostics,build:setup.identity})
console.log('native recovery passed '+phase+' '+record.output.sim_time_s+' s')
