import {setup,browser,json,sourceIdentity,preserveManifest,exportReadback} from './common.mjs'
import {readFileSync,cpSync} from 'node:fs'
import assert from 'node:assert/strict'
const out=setup.evidence+'/permission-revocation',frozen=JSON.parse(readFileSync(out+'/frozen.json','utf8')),id=frozen.id
sourceIdentity();browser('select','#workspace-history',id);browser('click','#workspace-load')
browser('wait','--fn',`document.querySelector('#workspace-diagnostics').textContent.includes('${id}')`)
const diagnostics=JSON.parse(browser('get','text','#workspace-diagnostics'))
assert.equal(diagnostics.status,'interrupted');assert.equal(diagnostics.confirmed_sim_time_s,frozen.storageFault.committed_sim_time_s)
assert.equal(diagnostics.unconfirmed_tail.end_sim_time_s,null);assert.equal(browser('is','enabled','#workspace-resume'),'false')
const exported=await exportReadback(id,out+'/reauthorized-download.json'),m=exported.recovery.record.manifest
assert.equal(exported.recovery.record.output.samples.length,Math.round(m.committed_sim_time_s/.01)+1)
assert.equal(exported.recovery.record.result.formal_acceptance,'not_eligible')
preserveManifest(setup.workspace,id,m)
const beforeManifest=JSON.parse(readFileSync(out+'/actual-before-from-snapshot.json','utf8')).manifest
for(const entry of [beforeManifest.config,beforeManifest.snapshot,beforeManifest.result,...beforeManifest.batches.flatMap(batch=>batch.files)])assert.deepEqual(readFileSync(out+'/before-revocation/experiments/'+id+'/'+entry.path),readFileSync(setup.workspace+'/experiments/'+id+'/'+entry.path))
browser('screenshot',out+'/reauthorized-history.png');cpSync(setup.workspace,out+'/after-native-reauthorization',{recursive:true})
json(out+'/result.json',{status:'passed',id,build:setup.identity,method:'Actual Chrome directory-grant revoke button; OS permissions unchanged; frozen state verified, then reload and explicit native reauthorization, history only',error:frozen.error,frozen_sim_time_s:frozen.storageFault.sim_time_s,confirmed_sim_time_s:frozen.storageFault.committed_sim_time_s,recovered_sim_time_s:m.committed_sim_time_s,samples:exported.recovery.record.output.samples.length,diagnostics,retained_failures:['stale-selection metadata in before.json; actual initial prefix recovered from pre-revocation snapshot','history read while access denied timed out; no denied-read pass claimed']})
console.log('real directory revocation and native recovery passed '+id+' '+m.committed_sim_time_s+' s')
