
import {setup,browser,json,sourceIdentity,connectWorker} from './common.mjs'
import {readFileSync,writeFileSync,mkdirSync,cpSync} from 'node:fs'
import {createHash} from 'node:crypto'
import assert from 'node:assert/strict'
const phase=process.argv[2],out=setup.evidence+'/'+phase
mkdirSync(out)
json(out+'/source.json',sourceIdentity())
const c=await connectWorker();await c.send('Debugger.enable')
const parsed=c.events.find(e=>e.method==='Debugger.scriptParsed'&&e.params.url===c.worker.url);assert.ok(parsed)
const {scriptSource:source}=await c.send('Debugger.getScriptSource',{scriptId:parsed.params.scriptId})
writeFileSync(out+'/worker.js',source)
const needle=phase==='temp-before-close'||phase==='manifest-before-close'?'await n.close()':'await e.read(t)!==n'
const condition=phase==='temp-before-close'?"e === 'tmp/pending.json'":phase==='manifest-before-close'?"e.endsWith('/manifest.json')":"t.includes('/confirmed/manifest-')"
const offset=source.indexOf(needle);assert.ok(offset>=0)
const lines=source.slice(0,offset).split('\n'),run=source.match(/let (\w+),(\w+),(\w+),(\w+)=Promise.resolve\(\)/)?.[2];assert.ok(run)
const guarded='('+condition+') && '+run+'?.progress().committed_sim_time_s >= 0.5 && '+run+'?.progress().status === \'running\''
const location={scriptId:parsed.params.scriptId,lineNumber:lines.length-1,columnNumber:lines.at(-1).length}
const breakpoint=await c.send('Debugger.setBreakpoint',{location,condition:guarded})
json(out+'/armed.json',{phase,needle,condition:guarded,location,breakpoint,worker:c.worker,worker_sha256:createHash('sha256').update(source).digest('hex')})
browser('click','#workspace-start')
let paused
for(let i=0;i<1200;i++){paused=c.events.find(e=>e.method==='Debugger.paused');if(paused)break;await new Promise(r=>setTimeout(r,50))}
assert.ok(paused,'actual breakpoint hit within 60s')
const evaluation=await c.send('Debugger.evaluateOnCallFrame',{callFrameId:paused.params.callFrames[0].callFrameId,expression:run+'.progress()',returnByValue:true})
assert.ok(!evaluation.exceptionDetails)
const progress=evaluation.result.value;assert.equal(progress.committed_sim_time_s,.5)
json(out+'/paused.json',{phase,paused,progress,time:new Date().toISOString()})
browser('screenshot',out+'/paused.png')
cpSync(setup.workspace,out+'/before-kill',{recursive:true})
const descendants=new Set([c.process.pid]);for(let i=0;i<8;i++)for(const p of c.process.processes)if(descendants.has(p.ppid))descendants.add(p.pid)
json(out+'/killed-processes.json',c.process.processes.filter(p=>descendants.has(p.pid)))
for(const pid of [...descendants].reverse())try{process.kill(pid,'SIGKILL')}catch{}
await new Promise(r=>setTimeout(r,300));cpSync(setup.workspace,out+'/after-kill',{recursive:true});c.socket.close()
console.log('cut passed '+phase+' '+progress.experiment_id)
