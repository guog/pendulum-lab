import assert from 'node:assert/strict'
import fs from 'node:fs'
const transcript = JSON.parse(fs.readFileSync('/tmp/pendulum-pr31-start-failure-repro.json', 'utf8'))
const nodes = new Map()
for (const id of ['open','read','identity','benchmark','preset','sampling','start','pause','resume','stop','retry','progress','error','history','load','export','diagnostics','record']) {
  nodes.set(id, { disabled: ['start','pause','resume','stop','retry','load','export'].includes(id), value: ({benchmark:'equilibrium',preset:'standard',sampling:'0.01'})[id] || '', options: [], textContent: '', replaceChildren(...children) { this.options = children; this.value = children[0]?.value || '' } })
}
const host = {setAttribute(){},querySelector(selector){ return nodes.get(selector.replace('#workspace-','')) }}
globalThis.document = { hidden:false,createElement(){return host},querySelector(){return {before(){}}},addEventListener(){} }
globalThis.window = {addEventListener(){}}
globalThis.Option = class { constructor(text,value){this.text=text;this.value=value} }
let worker
const sent=[]
globalThis.Worker = class {constructor(){worker=this} postMessage(value){sent.push(value)} }
const {initializeWorkspace}=await import('/Users/guog/.codex/worktrees/110c/pendulum-lab/src/workspace-ui.ts')
initializeWorkspace()
for(const data of transcript.opened) worker.onmessage({data})
nodes.get('start').onclick()
for(const data of transcript.start) worker.onmessage({data})
assert.equal(nodes.get('history').options.length,0)
assert.equal(nodes.get('load').disabled,true)
assert.equal(nodes.get('export').disabled,true)
assert.equal(nodes.get('retry').disabled,false)
console.log(JSON.stringify({scope:'Actual UI module using DOM/Worker adapters; no real Chrome claim',history_options:nodes.get('history').options,load_disabled:nodes.get('load').disabled,export_disabled:nodes.get('export').disabled,retry_disabled:nodes.get('retry').disabled,sent:sent.map(c=>c.type)},null,2))
