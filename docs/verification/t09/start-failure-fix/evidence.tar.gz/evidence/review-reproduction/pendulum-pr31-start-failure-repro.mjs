import assert from 'node:assert/strict'
import { createConfig } from '/Users/guog/.codex/worktrees/110c/pendulum-lab/src/session.ts'
const data = new Map()
const replies = []
let fail = false
function directory(prefix = '') {
  return {
    async queryPermission() { return 'granted' },
    async *keys() {
      const names = new Set([...data.keys()].filter(p => p.startsWith(prefix)).map(p => p.slice(prefix.length).split('/')[0]))
      yield* names
    },
    async getDirectoryHandle(name, { create = false } = {}) {
      const next = prefix + name + '/'
      if (!create && ![...data.keys()].some(p => p.startsWith(next))) throw new DOMException('missing', 'NotFoundError')
      return directory(next)
    },
    async getFileHandle(name, { create = false } = {}) {
      const path = prefix + name
      if (!create && !data.has(path)) throw new DOMException('missing', 'NotFoundError')
      return {
        async getFile() { const text = data.get(path); return { size: Buffer.byteLength(text), async text() { return text } } },
        async createWritable() {
          let value
          return {
            async write(text) {
              if (fail && path.endsWith('/samples/chunk-000002.csv')) throw new DOMException('revoked during start', 'NotAllowedError')
              value = text
            },
            async close() { data.set(path, value) },
            async abort() {},
          }
        },
      }
    },
  }
}
globalThis.postMessage = value => replies.push(value)
await import('/Users/guog/.codex/worktrees/110c/pendulum-lab/src/workspace.worker.ts')
async function command(data) {
  const offset = replies.length
  globalThis.onmessage({ data })
  for (let i = 0; i < 500; i++) {
    await new Promise(resolve => setTimeout(resolve, 2))
    const fresh = replies.slice(offset)
    if (fresh.some(v => v.type === 'error') || fresh.at(-1)?.type === 'list') return fresh
  }
  throw new Error('timeout')
}
const opened = await command({ type: 'open', handle: directory(), readonly: false })
assert.deepEqual(opened.find(r => r.type === 'opened').experiments, [])
fail = true
const start = await command({ type: 'start', config: createConfig('standard', 'equilibrium') })
const frozen = start.find(r => r.type === 'progress')
assert.equal(frozen.storage_fault.name, 'NotAllowedError')
assert.equal(start.find(r => r.type === 'error').hasRun, true)
assert.equal(start.some(r => r.type === 'list'), false)
assert.ok([...data.keys()].includes(`experiments/${frozen.experiment_id}/manifest.json`))
console.log(JSON.stringify({ opened, start, conclusion: 'The UI history remains empty despite a valid persisted prefix and frozen live run. Load and export stay disabled; open/start/stop/resume are disabled too.' }, null, 2))
