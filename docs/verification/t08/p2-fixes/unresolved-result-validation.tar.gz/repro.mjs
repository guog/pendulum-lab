import {pathToFileURL} from 'node:url';
const root=process.argv[2];
const {openWorkspace}=await import(pathToFileURL(`${root}/src/workspace.ts`));
const {createConfig}=await import(pathToFileURL(`${root}/src/session.ts`));
const {sha256}=await import(pathToFileURL(`${root}/src/evidence.ts`));
const data=new Map(); const files={permission:async()=>true,list:async(path)=>[...new Set([...data.keys()].filter(k=>k.startsWith(path?path+'/':'')).map(k=>k.slice(path?path.length+1:0).split('/')[0]))],read:async p=>{if(!data.has(p))throw Error('missing');return data.get(p)},write:async(p,t)=>{data.set(p,t)}};
const w=await openWorkspace(files);const r=await w.create(createConfig('standard','equilibrium'));await r.start();await r.advance(.1);await r.stop();
const mp=`experiments/${r.id}/manifest.json`,m=JSON.parse(data.get(mp)),rp=`experiments/${r.id}/${m.result.path}`,res=JSON.parse(data.get(rp));res.schema_version=999;res.status='running';res.rules_version='unsupported-future-version';res.last_state={x:123456789};const text=JSON.stringify(res);data.set(rp,text);m.result.sha256=await sha256(text);m.result.byte_length=new TextEncoder().encode(text).byteLength;data.set(mp,JSON.stringify(m));const loaded=await w.load(r.id);console.log(JSON.stringify({source_root:root,integrity:loaded.integrity,snapshot_status:loaded.output.status,result_status:loaded.result.status,result_schema:loaded.result.schema_version,result_rules:loaded.result.rules_version,result_state:loaded.result.last_state},null,2));
