import { readdirSync, readFileSync } from 'node:fs'
import { join, relative } from 'node:path'
import { createHash } from 'node:crypto'
const root=process.argv[2]
function walk(path){return readdirSync(path,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(path,e.name)):[join(path,e.name)])}
const files=walk(root).sort().map(path=>({path:relative(root,path),sha256:createHash('sha256').update(readFileSync(path)).digest('hex')}))
console.log(JSON.stringify({files,sha256:createHash('sha256').update(JSON.stringify(files)).digest('hex')},null,2))
