on run argv
 set operation to item 1 of argv
 tell application "System Events" to tell process "Google Chrome"
  if operation is "goto" then
   set targetPath to item 2 of argv
   if (count of sheets of front window) is not 1 then error "Expected directory picker"
   keystroke "g" using {command down, shift down}
   repeat 30 times
    if (count of sheets of sheet 1 of front window) is 1 then exit repeat
    delay 0.1
   end repeat
   set value of text field 1 of sheet 1 of sheet 1 of front window to targetPath
   key code 36
   repeat 30 times
    if (count of sheets of sheet 1 of front window) is 0 then exit repeat
    delay 0.1
   end repeat
   return value of pop up button 1 of sheet 1 of front window
  else if operation is "select" then
   set expectedFolder to item 2 of argv
   if (value of pop up button 1 of sheet 1 of front window) is not expectedFolder then error "Unexpected folder"
   click button "选择" of sheet 1 of front window
   return "selected " & expectedFolder
  else if operation is "cancel" then
   click button "取消" of sheet 1 of front window
   return "cancelled"
  else if operation is "allow" then
   if (name of front window) is not "允许此网站修改文件？" then error "Expected Chrome permission window"
   set permissionGroup to group 2 of group 1 of group 1 of group 1 of front window
   set promptName to name of static text 1 of group 1 of group 1 of scroll area 1 of permissionGroup
   if promptName does not contain "http://localhost:5183" then error "Unexpected origin"
   if promptName does not contain (item 2 of argv) then error "Unexpected directory"
   click button "允许" of group 1 of permissionGroup
   return "granted " & promptName
  else if operation is "state" then
   if (count of sheets of front window) > 0 then return {role, name, description} of every UI element of sheet 1 of front window
   set resultText to "no native sheet; buttons: "
   repeat with elementRef in entire contents of front window
    try
     if role of elementRef is "AXButton" then set resultText to resultText & (name of elementRef as text) & " | "
    end try
   end repeat
   return resultText
  end if
 end tell
end run
