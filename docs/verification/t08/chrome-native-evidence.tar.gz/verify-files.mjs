import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { join } from 'node:path'
import assert from 'node:assert/strict'
const [root,id,periodArg,durationArg,label] = process.argv.slice(2)
const period = Number(periodArg), duration = Number(durationArg)
const prefix=join(root,'experiments',id)
const raw=readFileSync(join(prefix,'manifest.json'),'utf8'), m=JSON.parse(raw)
assert.equal(m.sealed,true); assert.equal(m.experiment_id,id)
assert.equal(m.committed_sim_time_s,duration)
let verified=0
function content(entry){ const bytes=readFileSync(join(prefix,entry.path)); assert.equal(bytes.length,entry.byte_length,entry.path); assert.equal(createHash('sha256').update(bytes).digest('hex'),entry.sha256,entry.path); verified++; return bytes.toString('utf8') }
const config=JSON.parse(content(m.config)), snapshot=JSON.parse(content(m.snapshot)), result=JSON.parse(content(m.result))
assert.deepEqual(snapshot.config,config)
assert.equal(config.execution_mode,'authorized-directory')
assert.equal(config.timing.sample_period_s,period)
assert.equal(config.build_identity.source_revision,'96080f3e333e957be9326751f349bc8ba7b16472')
assert.equal(config.build_identity.source_dirty,false)
let samples=0,events=0,previous=-Infinity,last
for(const batch of m.batches){
 const lines=content(batch.files[0]).trimEnd().split('\n'), columns=lines.shift().split(',')
 const count=lines.length
 for(const line of lines){ const row=line.split(','); assert.equal(row.length,columns.length); const index=Number(row[0]),time=Number(row[1]); assert.equal(index,samples); assert.ok(time>previous); const expected=index*period; assert.ok(Math.abs(time-expected)<1e-10 || (time===duration && time<expected)); previous=time; last=time;samples++ }
 assert.equal(count,batch.sample_count)
 const eventText=content(batch.files[1]).trim(), part=eventText ? eventText.split('\n').map(JSON.parse):[]
 assert.equal(part.length,batch.event_count)
 for(const event of part){ assert.equal(event.event_index,events++); assert.equal(event.experiment_id,id); assert.equal(event.model_version,config.versions.model) }
}
assert.equal(samples,m.sample_count);assert.equal(events,m.event_count)
assert.equal(last,duration)
assert.equal(samples,Math.floor((duration+1e-12)/period)+1+(Math.abs(duration/period-Math.round(duration/period))>1e-10?1:0))
assert.equal(result.sample_count,samples);assert.equal(snapshot.sim_time_s,duration)
assert.equal(result.experiment_id,id);assert.equal(result.formal_acceptance,'not_eligible')
const summary={status:'passed',browser:'Chrome156 headed native directory picker + real macOS filesystem',directory:root,experiment_id:id,period_s:period,duration_s:duration,sample_count:samples,event_count:events,verified_file_references:verified,build_identity:config.build_identity,manifest:m,result}
writeFileSync('/tmp/pendulum-13-native-artifacts/'+label+'-verified.json',JSON.stringify(summary,null,2)+'\n')
console.log(JSON.stringify({status:'passed',samples,events,duration,verified_file_references:verified}))
