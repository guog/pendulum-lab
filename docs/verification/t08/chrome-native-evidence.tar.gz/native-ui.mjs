import { execFileSync } from 'node:child_process'
import { appendFileSync } from 'node:fs'
const args=process.argv.slice(2), file='/tmp/pendulum-13-native-artifacts/native-ui-steps.jsonl'
appendFileSync(file,JSON.stringify({phase:'start',time:new Date().toISOString(),args})+'\n')
try { const stdout=execFileSync('osascript',['/tmp/pendulum-13-native-artifacts/picker.applescript',...args],{encoding:'utf8',timeout:10000}); appendFileSync(file,JSON.stringify({phase:'finish',args,stdout})+'\n'); process.stdout.write(stdout) }
catch(error){appendFileSync(file,JSON.stringify({phase:'error',args,stderr:String(error.stderr),message:error.message})+'\n');throw error}
