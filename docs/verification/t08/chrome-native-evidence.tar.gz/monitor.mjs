import { createBrowser } from '/Users/guog/projects/github/guog/pendulum-lab/scripts/browser-driver.mjs'
import { writeFileSync, appendFileSync, readFileSync, readdirSync } from 'node:fs'
import assert from 'node:assert/strict'
const log = [], artifact = '/tmp/pendulum-13-native-artifacts'
const browser = createBrowser('pendulum-13-native', log, artifact+'/browser-steps.jsonl')
const label = process.argv[2]
const started = Date.now(), observations=[]
let observedRunning=false
while (Date.now()-started<600000) {
  const error = browser('get','text','#workspace-error')
  assert.equal(error, '')
  const text=browser('get','text','#workspace-progress')
  const match=text.match(/仿真 ([\d.]+) s · 已确认 ([\d.]+) s · 样本 (\d+) · 事件 (\d+)/)
  assert.ok(match, text)
  const [current,confirmed,samples,events]=match.slice(1).map(Number)
  assert.ok(current-confirmed<=1.000001, text)
  observations.push({elapsed_ms:Date.now()-started,text,current,confirmed,samples,events})
  if(observations.length%15===0) process.stdout.write(text+'\n')
  if (text.includes('状态 running')) observedRunning=true
  if (observedRunning && text.includes('已封存（完整性确认）')) {
    browser('screenshot',artifact+'/'+label+'-sealed.png')
    writeFileSync(artifact+'/'+label+'-observations.json',JSON.stringify(observations,null,2)+'\n')
    process.stdout.write('SEALED '+text+'\n'); process.exit(0)
  }
  await new Promise(resolve=>setTimeout(resolve,1000))
}
writeFileSync(artifact+'/'+label+'-observations.json',JSON.stringify(observations,null,2)+'\n')
throw new Error('Timed out waiting for seal')
